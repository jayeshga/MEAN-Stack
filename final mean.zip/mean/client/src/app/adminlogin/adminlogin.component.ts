import { Component } from '@angular/core';
import { AuthenticationService, TokenPayload } from '../authentication.service'
import { Router } from '@angular/router'

@Component({
 
  templateUrl: './adminlogin.component.html',
  
})
export class AdminloginComponent {
  credentials: TokenPayload = {
    _id: '',
    first_name: '',
    last_name: '',
    email: '',
    password: ''
  }

  constructor(private auth: AuthenticationService, private router: Router) {}

  adminlogin() {
    this.auth.login(this.credentials).subscribe(
      () => {
        this.router.navigateByUrl('/employee')
      },
      err => {
        console.error(err)
      }
    )
  }
}
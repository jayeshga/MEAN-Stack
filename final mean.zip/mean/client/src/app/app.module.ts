import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule } from '@angular/forms'
import { RouterModule, Routes } from '@angular/router'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProfileComponent } from './profile/profile.component'
import { LoginComponent } from './login/login.component'
import { RegisterComponent } from './register/register.component'
import { HomeComponent } from './home/home.component'
import { AuthenticationService } from './authentication.service'
import { AuthGuardService } from './auth-guard.service';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import{AdminNavComponent} from './admin-nav/admin-nav.component'
import{UserNavComponent} from './user-nav/user-nav.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component'
import { ChannelComponent } from './components/employee/channel.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { DailyComponent } from './daily/daily.component';
import { WealklyComponent } from './wealkly/wealkly.component';
import { MonthlyComponent } from './monthly/monthly.component';

const routes: Routes = [
  {path:'employee',component:ChannelComponent},
  { path: 'userNav', component: UserNavComponent },
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {path:'adminlogin',component:AdminloginComponent},
  {path:'adminregister',component:RegisterComponent},
  { path: 'adminNav', component: AdminNavComponent },
  { path: 'adminlogin', component: AdminloginComponent },
  { path: 'adminregister', component: AdminregisterComponent }, 
  { path: 'userdashboard', component: UserdashboardComponent }, 
  { path: 'daily', component: DailyComponent }, 
  { path: 'monthly', component: MonthlyComponent },
  { path: 'weakly', component: WealklyComponent },   
 
  {
    path: 'profile',
    component: ProfileComponent,
    canActivate: [AuthGuardService]
  },
  
  
]
@NgModule({
  declarations: [
    AppComponent,
    ProfileComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    AdminloginComponent,
    AdminregisterComponent,
    AdminNavComponent,
    UserNavComponent,
    UserdashboardComponent,
    UserdashboardComponent,
    ChannelComponent,
    DailyComponent,
    WealklyComponent,
    MonthlyComponent,
    
   
  ],
  imports: [
    MatCheckboxModule,
    BrowserModule,
    AppRoutingModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule
  ],
  providers: [AuthenticationService, AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import {AuthenticationService} from '../../authentication.service'
import { ChannelService } from '../../services/channel.service';
import { NgForm } from '@angular/forms';
import { Channel } from '../../models/channel';

declare var M: any;

@Component({
  selector: 'app-employee',
  templateUrl: './channel.component.html',
  styleUrls: ['./channel.component.css'],
  providers: [ ChannelService ]
})
export class ChannelComponent implements OnInit {

  constructor(public auth: AuthenticationService,public channelService: ChannelService) { }

  ngOnInit() {
    this.getChannels();
  }

  addChannel(form?: NgForm) {
    console.log(form.value);
    if(form.value._id) {
      this.channelService.putChannel(form.value)
        .subscribe(res => {
          this.resetForm(form);
          this.getChannels();
          M.toast({html: 'Updated Successfully'});
        });
    } else {
      this.channelService.postChannel(form.value)
      .subscribe(res => {
        this.getChannels();
        this.resetForm(form);
        M.toast({html: 'Save successfully'});
      });
    }
    
  }

  getChannels() {
    this.channelService.getChannels()
      .subscribe(res => {
        this.channelService.channels = res as Channel[];
      });
  }

  editChannel(channel: Channel) {
    this.channelService.selectedChannel = channel;
  }

  deleteChannel(_id: string, form: NgForm) {
    if(confirm('Are you sure you want to delete it?')) {
      this.channelService.deleteChannel(_id)
        .subscribe(res => {
          this.getChannels();
          this.resetForm(form);
          M.toast({html: 'Deleted Succesfully'});
        });
    }
  }

  resetForm(form?: NgForm) {
    if (form) {
      form.reset();
      this.channelService.selectedChannel = new Channel();
    }
  }

}

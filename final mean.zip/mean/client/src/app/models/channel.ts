export class Channel {

    constructor(_id = '', name = '', price = '') {
        this._id = _id;
        this.name = name;
        this.price = price;
       
    }

    _id: string;
    name: string;
    price: string;
  
}

import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { ChannelService } from '../services/channel.service';
import { Channel } from '../models/channel';
@Component({
  selector: 'app-monthly',
  templateUrl: './monthly.component.html',
  styleUrls: ['./monthly.component.css'],
  providers: [ChannelService],

})
export class MonthlyComponent implements OnInit {

  plan: { name: String; Price: number } = { name: '', Price: 0 };
  userChannelList: { name: String; price: Number }[] = [];

  constructor(
    
    public auth: AuthenticationService,
    public channelService: ChannelService
  ) {}
  ngOnInit(): void {
    this.getChannels();
  }

  getChannels() {
    this.channelService.getChannels().subscribe((res) => {
      console.log(res);
      this.channelService.channels = res as Channel[];
    });
  }

  addToPack(e, cname, cprice) {
    if (e.target.checked) {
      let c = {
        name: String = cname,
        price: Number = cprice,
      };
      this.userChannelList.push(c);
      console.log(this.userChannelList);
      this.plan.Price += cprice;
      console.log(this.plan.Price);
    }
  }


}

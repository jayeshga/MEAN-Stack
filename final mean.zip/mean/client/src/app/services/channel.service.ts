import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Channel } from '../models/channel';

@Injectable({
  providedIn: 'root'
})
export class ChannelService {

  selectedChannel: Channel;
  channels: Channel[];
  
  readonly URL_API = 'http://localhost:3000/api/channels';

  constructor(private http: HttpClient) {
    this.selectedChannel = new Channel();
  }

  postChannel(channel: Channel) {
    return this.http.post(this.URL_API, channel);
  }

  getChannels() {
    return this.http.get(this.URL_API);
  }

  putChannel(channel: Channel) {
    return this.http.put(this.URL_API + `/${channel._id}`, channel);
  }

  deleteChannel(_id: string) {
    return this.http.delete(this.URL_API + `/${_id}`);
  }
}

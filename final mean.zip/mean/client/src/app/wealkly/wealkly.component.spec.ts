import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WealklyComponent } from './wealkly.component';

describe('WealklyComponent', () => {
  let component: WealklyComponent;
  let fixture: ComponentFixture<WealklyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WealklyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WealklyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

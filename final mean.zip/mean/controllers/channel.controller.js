const Channel = require('../models/channel');

const channelCtrl = {};

channelCtrl.getChannels = async (req, res, next) => {
    const channels = await Channel.find();
    res.json(channels);
};

channelCtrl.createChannel = async (req, res, next) => {
    const channel = new Channel({
        name: req.body.name,
        price: req.body.price
      
    });
    await channel.save();
    res.json({status: 'Channel created'});
};

channelCtrl.getChannel = async (req, res, next) => {
    const { id } = req.params;
    const channel = await Channel.findById(id);
    res.json(channel);
};

channelCtrl.editChannel = async (req, res, next) => {
    const { id } = req.params;
    const channel = {
        name: req.body.name,
        price: req.body.price,
        
    };
    await Channel.findByIdAndUpdate(id, {$set: channel}, {new: true});
    res.json({status: 'Channel Updated'});
};

channelCtrl.deleteChannel = async (req, res, next) => {
    await Channel.findByIdAndRemove(req.params.id);
    res.json({status: 'Channel Deleted'});
};

module.exports = channelCtrl;
const express = require('express')
const admins = express.Router()
const cors = require('cors')
const jwt = require('jsonwebtoken')

const Admin = require('../models/Admin')
admins.use(cors())

process.env.SECRET_KEY = 'secret'

admins.post('/adminregister', (req, res) => {
  const today = new Date()
  const adminData = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    email: req.body.email,
    password: req.body.password,
    created: today
  }

  Admin.findOne({
    email: req.body.email
  })
    //TODO bcrypt
    .then(admin => {
      if (!admin) {
        Admin.create(adminData)
          .then(admin => {
            const payload = {
              _id: admin._id,
              firstname: admin.first_name,
              lastname: admin.last_name,
              email: admin.email
            }
            let token = jwt.sign(payload, process.env.SECRET_KEY, {
              expiresIn: 1440
            })
            res.json({ token: token })
          })
          .catch(err => {
            res.send('error: ' + err)
          })
      } else {
        res.json({ error: 'User already exists' })
      }
    })
    .catch(err => {
      res.send('error: ' + err)
    })
})

admins.post('/adminlogin', (req, res) => {
  Admin.findOne({
    email: req.body.email
  })
    .then(admin => {
      if (admin) {
        const payload = {
          _id: admin._id,
          first_name: admin.first_name,
          last_name: admin.last_name,
          email: admin.email
        }
        let token = jwt.sign(payload, process.env.SECRET_KEY, {
          expiresIn: 1440
        })
        res.json({
          success: true,
          token: `Bearer ${token}`,
          user: {
            id: admin._id,
            first_name: admin.first_name,
            last_name: admin.last_name,
            email:admin.email
          }
        });
      } else {
        res.json({ error: 'User does not exist' })
      }
    })
    .catch(err => {
      res.send('error: ' + err)
    })
})



module.exports = admins
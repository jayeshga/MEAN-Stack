const express = require('express');
const router = express.Router();

const channel = require('../controllers/channel.controller');

router.get('/', channel.getChannels);
router.post('/', channel.createChannel);
router.get('/:id', channel.getChannel);
router.put('/:id', channel.editChannel);
router.delete('/:id', channel.deleteChannel);

module.exports = router;
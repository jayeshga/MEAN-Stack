var express = require('express')
var cors = require('cors')
var bodyParser = require('body-parser')
var app = express()
const mongoose = require('mongoose')
var port = process.env.PORT || 3000

app.use(bodyParser.json())
app.use(cors())
app.use(
  bodyParser.urlencoded({
    extended: true
  })
)

const mongoURI = 'mongodb://localhost:27017/meanprojectdb'

mongoose
  .connect(
    mongoURI,
    { useNewUrlParser: true }
  )
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err))

var Users = require('./routes/Users')

app.use('/users', Users)

var Admins=require('./routes/Admin')

app.use('/admins',Admins)


var Chnnel=require('./routes/channel.routes')

app.use('/api/channels',Chnnel);

app.listen(port, function() {
  console.log('Server is running on port: ' + port)
})